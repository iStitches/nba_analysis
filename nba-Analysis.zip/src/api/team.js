import request from '@/utils/request'

/**
 * 球队数据接口
 */
export function teamRankAll(params){
   return request({
        url:'/api/team',
        method: 'get',
        params
    })
}

 //具体项目排名+该项的数据
 export function detailCompare(params){
    return request({
        url: '/api/team/itemRank',
        method: 'get',
        params
    })
}

//排名第一球队信息
export function firstTeam(params){
   return request({
       url: '/api/team/firstDetail',
       method: 'get',
       params
   })
}

//球队描述
export function top5Player(params) {
   return request({
       url: '/api/team/topDetail',
       method: 'get',
       params
   })
}