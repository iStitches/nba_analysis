import request from '@/utils/request'

/*
* MVP球员数据信息
*/

export function getPersonInfo() {
    return request({
      url: 'api/mvp/personInfo',
      method: 'get'
    })  
  }
  
  export function getStrength() {
    return request({
      url: 'api/mvp/strength',
      method: 'get'
    })  
  }
  
  export function getDetail(params) {
    return request({
      url: 'api/mvp/detail',
      method: 'get',
      params
    })  
  }