import request from '@/utils/request'
  
export function getPlayerRank(params) {
  return request({
    url: '/api/player/itemRank',
    method: 'get',
    params
  })
}
