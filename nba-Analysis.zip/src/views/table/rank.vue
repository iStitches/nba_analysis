<template>
   <div class="team-main">
       <el-row>
          <el-col :span="24">
             <rank-table :tableData="tableData"></rank-table>
          </el-col>
       </el-row>
       <el-row style="margin-top: 30px">
          <el-col :span="24" class="pagiNation">
              <el-pagination
                background
                style="width: 800px"
                layout="total, sizes, prev, pager, next, jumper"
                :total="total" 
                :current-page="pageNum"
                :page-size="pageSize"
                :page-sizes="[5,8,10]"
                @size-change="handleSizeChange"
                @current-change="handleCurrentChange">
              </el-pagination>
          </el-col>
       </el-row>
          

   </div>
</template>

<script>
import RankTable from '@/components/rankTable/RankTable.vue'
import { teamRankAll } from '@/api/team'

export default {
  data() {
    return{
        tableData: [],
        pageNum: 1,    //当前页码
        pageSize: 5,  //每页记录数
        total: 30       //总条目数
    }
  },
  created(){     //初始默认第一页，5条数据
     teamRankAll({
       "pageSize":this.pageSize,
       "pageNum":this.pageNum
     }).then(res=>{
       const table = res.data
       this.tableData = res.data
     })
  },
  methods: {
    handleSizeChange(val){  //更改每页条数
        this.pageSize = val
        this.reGetTable()
    },
    handleCurrentChange(val){  //翻页
        this.pageNum = val
        this.reGetTable()
    },
    reGetTable(){    //重新获取数据
        teamRankAll({
          "pageSize":this.pageSize,
          "pageNum":this.pageNum
        }).then(res=>{
          console.log(this.res)
          const table = res.data
          this.tableData = res.data
        })
    }
  },
  components:{
     RankTable
  }
}
</script>

<style  scoped>
.team-main{
   background: #f6f6f6;
   height: 1200px;
   width: 100%;
}
.pagiNation{
     display: flex;
   justify-content: center;
}
.pagiNation>>> .el-pager li{
   background-color: transparent !important;
   color: #0256FA !important;
   border: 1px solid #0672C4;
   min-width: 40px;
   min-height: 40px;
   text-align: center;
   font-size: 16px;
   line-height: 40px;
}

.pagiNation>>> .el-pagination.is-background .el-pager li:not(.disabled).active {
    background-color:  #0258FF !important;
    color: white!important;
}
.pagiNation>>> .el-pagination span:not([class*=suffix]){
  line-height: 45px;
}
.pagiNation>>> .el-pagination button{
  height: 40px;
}
</style>
