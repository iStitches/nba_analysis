<template>
   <div class="team-main">
       <btn-head>
           <btn-item v-for="(item,index) in btnsRow1" :key="index" :iconPath="item.iconPath" :des="item.des" slot="firstRow"  @click.native="refreshData(item)"></btn-item>
           <btn-item v-for="(item,index) in btnsRow2" :key="index" :iconPath="item.iconPath" :des="item.des" slot="secondRow" @click.native="refreshData(item)"></btn-item>
       </btn-head>
        <!--胜负场排名+图-->
        <el-row type="flex" justify="start" class="rank-all">
            <el-col :span="8" class="rank-list">
               <rank-list :name="curBtn" :list="list"></rank-list>
            </el-col>
            <el-col :span="8" class="rank-chart">
                <el-tabs  v-model="teamActivePage" :tab-position="'right'" style="height: 460px;width: 700px" @tab-click="handleTeamChartRefresh">
                    <el-tab-pane v-for="(page,index) in team_pages" :key="index" :name="page.name">
                        <span slot="label"><h3>{{page.name}}</h3></span>
                        <graph-charts v-if="page.name==nowPage_team && page.sign==1" :option="team_option_list[index]" style="width:577.5px;height:400px;margin-top:20px;margin-left:14px" :time="time"></graph-charts>
                        <graph-echarts v-if="page.name==nowPage_team && page.sign==2" :option="team_option_list[index]" style="width:577.5px;height:400px;margin-top:20px;margin-left:14px" :time="time"></graph-echarts>
                    </el-tab-pane>
                </el-tabs>
            </el-col>
        </el-row>

        <!--其他项目-->
        <el-row class="title" type="flex" align="bottom">
            <el-col :span="24" :offset="2">
                <div class="banner banner-blue">
                    <h3>球队先锋</h3>
                </div>
            </el-col>
        </el-row>
        <el-row type="flex" justify="start" class="rank-all" align="top">
            <el-col :span="8" :offset="1">
                <div class="info-avatar">
                    <avatar-info :teamInfo="teamInfo" :teamInfo_imgList="teamInfo_imgList"></avatar-info>
                </div>
            </el-col>
            <el-col :span="8" class="player-info">        
                <el-tabs v-model="playerActivePage" @tab-click="handlePlayerChartRefresh" style="width: 560px;margin-left: 40px;height: 500px">
                     <el-tab-pane v-for="(page,index) in player_pages" :key=index :label="page.label" :name="page.name">
                        <graph-charts v-if="page.name==nowPage_player && page.sign==1"  :option="player_option_list[index].option" :width="'560px'" :height="'350px'" :time="time"></graph-charts>
                        <graph-echarts v-if="page.name==nowPage_player && page.sign==2"  :option="player_option_list[index].option" :width="'560px'" :height="'350px'" :time="time"></graph-echarts>
                     </el-tab-pane>
                </el-tabs>
            </el-col>
        </el-row>
   </div>
</template>

<script>
import BtnHead from '../../components/btnHead/btnHead.vue'
import BtnItem from '../../components/btnHead/btnIteam.vue'
import RankList from '../../components/rankList/rankList.vue'
import GraphCharts from '../../components/highChart/GraphCharts.vue'
import GraphEcharts from '../../components/echart/GraphCharts.vue'
import AvatarInfo from '../../components/avatarInfo/avatarInfo.vue'
import uuidv1 from 'uuid/v1'
import { detailCompare } from '@/api/team'
import { firstTeam } from '@/api/team'
import { top5Player } from '@/api/team'

export default {
  name:'',
  data(){
      return{
         teamActivePage: '柱状图',
         playerActivePage: 'score',     //球员默认加载项目
         nowPage_player: 'score',       //球员信息当前需要加载的项目
         nowPage_team: '柱状图',        //球队信息当前需要加载的项目
         curBtn: "胜负场",                 //按钮点击数据项
         player_pages: [                //所有页面   sign：选择highcharts还是echarts进行渲染
             {name: 'score', label: '均场得分', sign: 1},
             {name: 'basket', label: '均场篮板', sign: 1},
             {name: 'help', label: '均场助攻', sign: 1},
             {name: 'rob', label: '均场抢断', sign: 2},
             {name: 'cover', label: '均场盖帽', sign: 2}
         ],
         team_pages: [
             {name: '柱状图', id:'chart1', sign: 1},
             {name: '折线图', id:'chart2', sign: 1},
             {name: '饼状图', id:'chart3', sign: 2},
             {name: '环形图', id:'chart4', sign: 2}
         ],
         rankName: 'W_L',         //正在排序的属性项的名称
         btnsRow2: [
            {iconPath: require('../../assets/img/助攻.png'),des: '助攻'},
            {iconPath: require('../../assets/img/抢断.png'),des: '抢断'},
            {iconPath: require('../../assets/img/封盖.png'),des: '封盖'},
            {iconPath: require('../../assets/img/犯规.png'),des: '犯规'},
        ],
         btnsRow1: [
            {iconPath: require('../../assets/img/胜负场.png'),des: '胜负场'},
            {iconPath: require('../../assets/img/罚球.png'),des: '罚球'},
            {iconPath: require('../../assets/img/三分球.png'),des: '三分球'},
            {iconPath: require('../../assets/img/篮板.png'),des: '篮板'}
         ],
         list: [                  //排名栏
                {
                    name: "密尔沃基雄鹿",
                    img: "http://mat1.gtimg.com/sports/nba/logo/1602/15.png",
                    score: 51.7
                },
                {
                    name: "布鲁克林篮网",
                    img: "http://mat1.gtimg.com/sports/nba/logo/1602/17.png",
                    score: 47.9
                },
                {
                    name: "洛杉矶快船",
                    img: "http://mat1.gtimg.com/sports/nba/logo/1602/1201.png",
                    score: 47.7
                },
                {
                    name: "达拉斯独行侠",
                    img: "http://mat1.gtimg.com/sports/nba/logo/1602/6.png",
                    score: 118.7
                },
                {
                    name: "新奥尔良鹈鹕",
                    img: "http://mat1.gtimg.com/sports/nba/logo/1602/3.png",
                    score: 118.7
                }             
         ],
         team_option_list: [      //球队option数据
             //柱状图
            {
                chart: {
                    type: 'column'
                },
                title: {
                    text: '包含负值的柱形图'
                },
                xAxis: {
                    categories: ['胜','负']
                },
                series: [{
                    name: '球队1',
                    data: [5, -2]
                }, {
                    name: '球队2',
                    data: [2, -2]
                }, {
                    name: '球队3',
                    data: [3, -4]
                },  {
                    name: '球队4',
                    data: [7, -3]
                },  {
                    name: '球队5',
                    data: [8, -6]
                }]
            },
                //折线图
            {
                chart: {
                    type: 'area'
                },
                title: {
                    text: '全球各大洲人口增长历史及预测'
                },
                subtitle: {
                    text: '数据来源: 虎扑体育、腾讯体育'
                },
                xAxis: {
                    categories: ['赛季1', '赛季2', '赛季3', '赛季4', '赛季5'],
                    tickmarkPlacement: 'on',
                    title: {
                        enabled: false
                    }
                },
                yAxis: {
                    title: {
                        text: '数值'
                    },
                    labels: {
                        formatter: function () {
                            return this.value;
                        }
                    }
                },
                tooltip: {
                    split: true,
                    valueSuffix: ' 个'
                },
                plotOptions: {
                    area: {
                        stacking: 'normal',
                        lineColor: '#666666',
                        lineWidth: 1,
                        marker: {
                            lineWidth: 1,
                            lineColor: '#666666'
                        }
                    }
                },
                series: [{
                    name: '亚洲',
                    data: [20, 20, 20, 20, 20]
                }, {
                    name: '非洲',
                    data: [20,20, 20, 20, 20]
                }, {
                    name: '欧洲',
                    data: [163, 203, 276, 408, 547]
                }, {
                    name: '美洲',
                    data: [18, 31, 54, 156, 339]
                }, {
                    name: '大洋洲',
                    data: [2, 2, 2, 6, 13]
                }]
            },
            //饼状图
            {
                title: {
                    text: 'sdfsdfs',
                    subtext: '虎扑体育、腾讯体育',
                    left: 'center'
                },
                tooltip: {
                    trigger: 'item',
                    formatter: '{a} <br/>{b} : {c} ({d}%)'
                },
                legend: {
                    left: 'center',
                    top: 'bottom',
                    data: ['rose1', 'rose2', 'rose3', 'rose4', 'rose5', 'rose6', 'rose7', 'rose8']
                },
                toolbox: {
                    show: true,
                    feature: {
                        mark: {show: true},
                        dataView: {show: true, readOnly: false},
                        magicType: {
                            show: true,
                            type: ['pie', 'funnel']
                        },
                        restore: {show: true},
                        saveAsImage: {show: true}
                    }
                },
                series: [
                    {
                        name: 'sdfs',
                        type: 'pie',
                        radius: [20, 110],
                        center: ['50%', '50%'],
                        roseType: 'radius',
                        label: {
                            show: false
                        },
                        emphasis: {
                            label: {
                                show: true
                            }
                        },
                        data: [
                            {value: 10, name: 'rose1'},
                            {value: 5, name: 'rose2'},
                            {value: 15, name: 'rose3'},
                            {value: 25, name: 'rose4'},
                            {value: 20, name: 'rose5'},
                            {value: 35, name: 'rose6'},
                            {value: 30, name: 'rose7'},
                            {value: 40, name: 'rose8'}
                        ]
                    }
                ]
            },
            //环形图
            {
            title: {
                    text: 'sdfsdfs',
                    left: 'center'
                },
            tooltip: {
                trigger: 'item',
                formatter: '{a} <br/>{b}: {c} ({d}%)'
            },
            legend: {
                orient: 'vertical',
                left: 10,
                data: ['雄鹿', '猛龙', '凯尔特人', '步行者', '热火']
            },
            series: [
                {
                    name: 'sdfsdf',
                    type: 'pie',
                    radius: ['50%', '70%'],
                    avoidLabelOverlap: false,
                    label: {
                        show: false,
                        position: 'center'
                    },
                    emphasis: {
                        label: {
                            show: true,
                            fontSize: '30',
                            fontWeight: 'bold'
                        }
                    },
                    labelLine: {
                        show: false
                    },
                    data: [
                        {value: 335, name: '雄鹿'},
                        {value: 310, name: '猛龙'},
                        {value: 234, name: '凯尔特人'},
                        {value: 135, name: '步行者'},
                        {value: 1548, name: '热火'}
                    ]
                }
            ]
            }
         ],
         player_option_list: [    //球员option数据
             {
                 id: "playerRank_score",
                 option: {
                            chart: {
                            type: 'line'
                            },
                            title: {
                                text: '均厂得分'
                            },
                            subtitle: {
                                text: '数据来源: https://sports.qq.com'
                            },
                            xAxis: {
                                categories: ['近1场','近3场','近6场','近9场','近12场']
                            },
                            yAxis: {
                                title: {
                                    text: '得分 (分)'
                                }
                            },
                            plotOptions: {
                                line: {
                                    dataLabels: {
                                        // 开启数据标签
                                        enabled: true          
                                    },
                                    // 关闭鼠标跟踪，对应的提示框、点击事件会失效
                                    enableMouseTracking: false
                                }
                            },
                            series: [{
                                name: 'Tyler Herro',
                                data: [7.0, 6.9, 9.5, 14.5, 18.4]
                            }, {
                                name: '邓肯-鲁滨逊',
                                data: [3.9, 4.2, 5.7, 8.5, 11.9],
                            }, {
                                name: '肯德里克-纳恩',
                                data: [15.2, 17.0, 16.6, 14.2, 10.3],
                            }, {
                                name: '巴姆-阿德巴约',
                                data: [3.9, 6.6, 4.8, 5.2,9.8],
                            }, {
                                name: '迈尔斯-莱昂纳德',
                                data: [10.6,8.4,5.3,6.2,12.0],
                            }]
                        }
             },
             {
                 id: "playerRank_basket",   
                 option:   {
                            title: {
                                text: '均厂篮板',
                                align: 'center',
                                verticalAlign: 'middle',
                                y: 50
                            },
                            tooltip: {
                                headerFormat: '{series.name}<br>',
                                pointFormat: '{point.name}: <b>{point.percentage:.1f}%</b>'
                            },
                            plotOptions: {
                                pie: {
                                    dataLabels: {
                                        enabled: true,
                                        distance: -50,
                                        style: {
                                            fontWeight: 'bold',
                                            color: 'white',
                                            textShadow: '0px 1px 2px black'
                                        }
                                    },
                                    startAngle: -90, // 圆环的开始角度
                                    endAngle: 90,    // 圆环的结束角度
                                    center: ['50%', '75%']
                                }
                            },
                            series: [{
                                type: 'pie',
                                name: '篮板数',
                                innerSize: '50%',
                                data: [
                                    ['Tyler Herro',   5.0],
                                    ['迈尔斯-莱昂纳德',       4.0],
                                    ['埃弗里-布拉德利', 4.0],
                                    ['巴姆-阿德巴约',    3.0],
                                    ['肯德里克-纳恩',     3.0],
                                    {
                                        name: '其他',
                                        y: 0.7,
                                        dataLabels: {
                                            // 数据比较少，没有空间显示数据标签，所以将其关闭
                                            enabled: false
                                        }
                                    }
                                ]
                            }]
                        }            
             },
             {
                 id: "playerRank_help",
                 option: {
                        chart: {
                        type: 'column'
                        },
                        title: {
                            text: '均厂助攻'
                        },
                        subtitle: {
                            text: '数据来源: https://sports.qq.com/'
                        },
                        xAxis: {
                            categories: [
                                '近3场','近6场','近9场','近12场','近15场'
                            ],
                            crosshair: true
                        },
                        yAxis: {
                            min: 0,
                            title: {
                                text: '助攻数 (次)'
                            }
                        },
                        tooltip: {
                            // head + 每个 point + footer 拼接成完整的 table
                            headerFormat: '<span style="font-size:10px">{point.key}</span><table>',
                            pointFormat: '<tr><td style="color:{series.color};padding:0">{series.name}: </td>' +
                            '<td style="padding:0"><b>{point.y:.1f} mm</b></td></tr>',
                            footerFormat: '</table>',
                            shared: true,
                            useHTML: true
                        },
                        plotOptions: {
                            column: {
                                borderWidth: 0
                            }
                        },
                        series: [{
                            name: '巴姆-阿德巴约',
                            data: [49.9, 71.5, 106.4, 129.2, 144.2]
                        }, {
                            name: 'Tyler Herro',
                            data: [83.6, 78.8, 98.5, 93.4, 106.0]
                        }, {
                            name: '	肯德里克-纳恩',
                            data: [48.9, 38.8, 39.3, 41.4, 47.0]
                        }, {
                            name: '	Precious Achiuwa',
                            data: [42.4, 33.2, 34.5, 39.7, 52.6]
                        }, {
                            name: '迈尔斯-莱昂纳德',
                            data: [75.5, 57.4, 60.4, 47.6, 39.1]
                        }]
                 }
             },
             {
                 id: "playerRank_Rob",
                 option: {
                        backgroundColor: '#FFFFFF',
                        grid: {
                            height: "250px"
                        },
                        tooltip: {
                            trigger: 'axis',
                            axisPointer: {
                                type: 'cross',
                                crossStyle: {
                                    color: '#999'
                                }
                            }
                        },
                        toolbox: {
                            feature: {
                                dataView: {show: false, readOnly: false},
                                magicType: {show: false, type: ['line', 'bar']},
                                restore: {show: false},
                                saveAsImage: {show: false}
                            }
                        },
                        legend: {
                            data: ['巴姆-阿德巴约', '迈尔斯-莱昂纳德', 'Precious Achiuwa','埃弗里-布拉德利','安德鲁-伊格达拉']
                        },
                        xAxis: [
                            {
                                type: 'category',
                                data: ['近3场', '近6场', '近9场', '近12场', '近15场'],
                                axisPointer: {
                                    type: 'shadow'
                                }
                            }
                        ],
                        yAxis: [
                            {
                                type: 'value',
                                name: '抢断次数',
                                min: 0,
                                max: 50,
                                interval: 5,
                                axisLabel: {
                                    formatter: '{value} 次'
                                }
                            },
                            {
                                type: 'value',
                                name: '最多抢断',
                                min: 0,
                                max: 50,
                                interval: 5,
                                axisLabel: {
                                    formatter: '{value} 次'
                                }
                            }
                        ],
                        series: [
                            {
                                name: '巴姆-阿德巴约',
                                type: 'bar',
                                data: [5,12,18,25,36]
                            },
                            {
                                name: '迈尔斯-莱昂纳德',
                                type: 'bar',
                                data: [1,7,20,23,40]
                            },
                            {
                                name: 'Precious Achiuwa',
                                type: 'bar',
                                data: [3,4,11,17,10]
                            },
                            {
                                name: '埃弗里-布拉德利',
                                type: 'bar',
                                data: [2,6,20,34,22]
                            },
                            {
                                name: '安德鲁-伊格达拉',
                                type: 'bar',
                                data: [5,10,15,20,25]
                            },
                            {
                                name: '最多抢断',
                                type: 'line',
                                yAxisIndex: 1,
                                data: [5,12,20,34,40]
                            }
                        ]
                 }
             },
             {
                 id: "playerRank_Cover",
                 option: {
                        legend: {},
                        grid: {
                            height: "250px"
                        },
                        tooltip: {
                            trigger: 'axis',
                            axisPointer: {
                                type: 'cross',
                                crossStyle: {
                                    color: '#999'
                                }
                            }
                        },
                        dataset: {
                            dimensions: ['CoverHat', '迈尔斯-莱昂纳德', '毛里斯-哈克里斯', '巴姆-阿德巴约','埃弗里-布拉德利','安德鲁-伊格达拉'],
                            source: [
                                {CoverHat: '近3场', '迈尔斯-莱昂纳德': 43.3, '毛里斯-哈克里斯': 85.8, '巴姆-阿德巴约': 93.7,'埃弗里-布拉德利': 100.7,'安德鲁-伊格达拉':140.5},
                                {CoverHat: '近6场', '迈尔斯-莱昂纳德': 83.1, '毛里斯-哈克里斯': 73.4, '巴姆-阿德巴约': 55.1,'埃弗里-布拉德利': 62.0,'安德鲁-伊格达拉':78.6},
                                {CoverHat: '近9场', '迈尔斯-莱昂纳德': 86.4, '毛里斯-哈克里斯': 65.2, '巴姆-阿德巴约': 82.5,'埃弗里-布拉德利': 90.5,'安德鲁-伊格达拉':130.5},
                                {CoverHat: '近12场', '迈尔斯-莱昂纳德': 72.4, '毛里斯-哈克里斯': 53.9, '巴姆-阿德巴约': 39.1,'埃弗里-布拉德利': 45.3,'安德鲁-伊格达拉':77.2},
                                {CoverHat: '近15场', '迈尔斯-莱昂纳德': 88.3, '毛里斯-哈克里斯': 53.9, '巴姆-阿德巴约': 39.1,'埃弗里-布拉德利': 100.7,'安德鲁-伊格达拉':140.5}
                            ]
                        },
                        xAxis: {type: 'category'},
                        yAxis: {},
                        series: [
                            {type: 'bar'},
                            {type: 'bar'},
                            {type: 'bar'},
                            {type: 'bar'},
                            {type: 'bar'}
                        ]
                 }
             }
         ],
         teamInfo:{
                name:'雄鹿',
                area:'美国,佛罗里达州,迈阿密',
                famous:'德怀恩·韦德，阿朗佐·莫宁，乌杜尼斯·哈斯勒姆',
                coach:'埃里克·斯波尔斯特拉',
                honor:'3次NBA总冠军;6次NBA东部联盟冠军'
         },
         teamInfo_imgList:[
         ],
         time: '6'
      }
  },
  components:{
      BtnHead,
      BtnItem,
      RankList,
      GraphCharts,
      AvatarInfo,
      GraphEcharts
  },
  methods:{
      handlePlayerChartRefresh(tab){  //球员个人数据栏切换
          this.nowPage_player = tab.name
          this.getTopPlayerData()
      },
      refreshData(item){           //按钮刷新
            this.curBtn=item.des
            switch(item.des){
                case '胜负场':
                    this.rankName='W_L'
                    break;
                case '罚球':
                    this.rankName='FT'
                    break;
                case '三分球':
                    this.rankName='3P'
                    break;
                case '篮板':
                    this.rankName='TRB'
                    break;
                case '助攻':
                    this.rankName='AST'
                    break;
                case '抢断':
                    this.rankName='STL'
                    break;
                case '封盖':
                    this.rankName='BLK'
                    break;
                case '犯规':
                    this.rankName='PF'
                    break;
                default: {}
                }
            this.getTopTeamInfo()
      },
      handleTeamChartRefresh(tab){
          this.nowPage_team = tab.name
          this.repaintTeamGraph()
      },
      getRankData(){      //初始数据渲染
          detailCompare({
              "item": this.rankName
          }).then(res=>{
              console.log(res)
              this.list=res.data
              this.repaintTeamGraph()
              this.getTopTeamInfo()
          })
      },
      repaintTeamGraph(){    //球队图像渲染
          switch(this.nowPage_team){
            case '柱状图':
              {
                  var temp = []
                  //展示胜负场
                  if(this.rankName == 'W_L'){
                      this.team_option_list[0].xAxis.categories=['胜场','负场']
                      for(var i=0;i<5;i++){
                        temp.push(
                            {
                                name: this.list[i].name,
                                data: [this.list[i].first_season_W,this.list[i].first_season_L*-1]
                            }
                        )
                      }
                  }
                  else{
                    //展示其它
                    this.team_option_list[0].xAxis.categories=['赛季1','赛季2','赛季3','赛季4','赛季5']
                    for(var i=0;i<5;i++){
                        temp.push(
                        {
                            name: this.list[i].name,
                            data: [this.list[i].first_season,this.list[i].second_season,this.list[i].third_season,this.list[i].forth_season,this.list[i].fifth_season]
                        })
                    }
                  }
                   this.team_option_list[0].series=temp
                   this.team_option_list[0].title.text=this.curBtn
              }break;
            case '折线图':
              {
                  var series = []
                    for(var i=0;i<5;i++){
                        if(this.rankName == 'W_L'){
                            series.push(
                                {
                                    name: this.list[i].name,
                                    data: [this.list[i].first_season_W,this.list[i].second_season_W,this.list[i].third_season_W,this.list[i].forth_season_W,this.list[i].fifth_season_W]
                                }
                                )
                        }
                        else{
                            series.push(
                                {
                                    name: this.list[i].name,
                                    data: [this.list[i].first_season,this.list[i].second_season,this.list[i].third_season,this.list[i].forth_season,this.list[i].fifth_season]
                                }
                            )
                        }
                    }
                  this.team_option_list[1].series=series
                  this.team_option_list[1].title.text=this.curBtn

              }break;
            case '饼状图':
              {
                    var temp = []
                    var legend = []
                    for(var i=0;i<5;i++){
                        if(this.rankName == 'W_L'){
                            temp.push(
                                {
                                    value: this.list[i].first_season_W,
                                    name: this.list[i].name
                                })
                            legend.push(this.list[i].name)
                        }
                        else{
                            temp.push(
                                {
                                    value: this.list[i].first_season,
                                    name: this.list[i].name
                                })
                            legend.push(this.list[i].name)
                        }
                    }
                    this.team_option_list[2].series[0].data=temp
                    this.team_option_list[2].legend.data = legend
                    this.team_option_list[2].series[0].name=this.curBtn
                    this.team_option_list[2].title.text=this.curBtn
              }break;
            case '环形图':
              {
                  var legend = []
                  var series = []
                    for(var i=0;i<5;i++){
                        legend.push(this.list[i].name)
                        if(this.rankName == 'W_L'){
                            series.push(
                            {
                                name: this.list[i].name,
                                value: [this.list[i].first_season_W,this.list[i].second_season_W,this.list[i].third_season_W,this.list[i].forth_season_W,this.list[i].fifth_season_W]
                            })
                        }
                        else{
                            series.push(
                            {
                                name: this.list[i].name,
                                value: [this.list[i].first_season,this.list[i].second_season,this.list[i].third_season,this.list[i].forth_season,this.list[i].fifth_season]
                            })
                        }
                  }
                  this.team_option_list[3].legend.data = legend
                  this.team_option_list[3].series[0].data = series
                  this.team_option_list[3].title.text=this.curBtn
                  this.team_option_list[3].series[0].name=this.curBtn
              }
            default:{

            }
          }
          //更新time值子组件重画
          this.time=uuidv1()
      },
      getTopTeamInfo(){  //获取top球队的信息
          firstTeam({
              "item": this.list[0].name
          }).then(res=>{
              for(var i=0;i<6;i++){
                  this.$set(this.teamInfo_imgList,i,                       
                        {
                            cnName:res.data[i].cnName,
                            img:res.data[i].img
                        })
              }
          })
      }
  },
  mounted(){   //初始化渲染数据
      this.getRankData()
  },
  watch:{
      rankName(newName,oldName){
           this.getRankData()
      }
  }
}
</script>

<style scoped>
.team-main{
    background:  #f6f6f6;
    height: 1500px;
}
.rank-all{
    width: 90%;
    max-height: 600px;
    margin: 40px auto 20px auto;
}
.rank-chart{
    display: flex;
    align-items: center;
    margin-left: 50px;
    width: 700px;
}
.rank-list{
    margin-left: 40px;
}
.rank-chart div{
    box-shadow: 0 2px 12px 0 rgba(0,0,0,.1);
}
.info-avatar{
    height: 450px;
    width: 500px;
    display: flex;
    align-items: center;
    justify-content: center;
}
.player-info{
    margin-left: 100px;
    width: 600px;
    display: flex;
    justify-content: center;
    margin-top: 10px;
}
.player-rank{
    height: 500px;
    width: 700px;
    display: flex;
    align-items: center;
    justify-content: center;
}
.title{
    margin-top: 50px;
    width: 90%;
}
.title .banner{
    height: 35px;
    line-height: 35px;
    color: #ffffff;
    background: #f3f3f3 url(//img1.gtimg.com/sports/pics/hv1/254/252/1914/124522364.png) left top no-repeat;
}
.title .banner-blue{
    background-color: #004576;
}
.banner h3{
    margin-left: 42px;
    font-size: 14px;
    font-weight: 400;
    cursor: default;
}
.rank-chart >>> .el-tabs__item{
    height: 80px;
    line-height: 5;
}
</style>
