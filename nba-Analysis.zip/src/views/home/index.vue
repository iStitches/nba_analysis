<template>
    <div class="main" style="height: 1100px;background: #f6f6f6">
      <!--走马灯-->
      <el-row type="flex" justify="center" style="margin-top: 20px">
          <el-col :span="24" class="carousel-header">
             <el-carousel :interval="4000" type="card" height="357px">
              <el-carousel-item v-for="(item,index) in img_list" :key="index">
                 <img :src="img_list[index]" alt="">
              </el-carousel-item>
            </el-carousel>
          </el-col>
      </el-row>
      
      <!--标题-->
      <el-row type="flex" justify="center">
          <el-col :span="24" class="title">
              <h3>今日要闻</h3>
              <div></div>
          </el-col>
      </el-row>

      <!--今日要闻-->
      <el-row type="flex" justify="center" align="middle">
          <el-col :span="12" class="content">
             <h3><a href=" ">正视频直播勇士vs国王</a></h3>
             <span>汇总：火箭轮休沃尔考神 韦少战活塞缺阵</span>
             <h3><a href=" ">NBA为黑人社区捐200万美元 承诺10年投3亿</a></h3>
             <span>NBA高管认为哈登无法适应热火文化 和巴特勒不合</span>
             <h3><a href=" ">哈登终于愿意接受采访：前往拉斯维加斯就是去训练</a></h3>
             <span>杜兰特：打勇士没啥特别 揭幕战就碰老队友很棒</span>
             <h3><a href=" ">哈登终于愿意接受采访：前往拉斯维加斯就是去训练</a></h3>
             <span>洛瑞：未讨论新合同 目标是帮球队赢得总冠军</span>
             <h3><a href=" ">字母哥续约背后不为人知的原因 因为他母亲说不想搬家</a></h3>
             <span>名嘴：哈登并非先天巨星 无法到哪里都赢球</span>
             <h3><a href=" ">湖人新援表明态度：不会和詹皇抢球权 会努力适应球队</a></h3>
             <span>湖人美女老板给全队送礼物 刻着球员名字＋口号</span>
             <h3><a href=" ">浓眉哥飘了？库兹马调侃买豪车，哈雷尔：检测还得带个保镖</a></h3>
             <span>魔术执行班巴新秀合同第四年选项 他能否兑现天赋？</span>
          </el-col>
          <el-col :span="12" class="picture">
             <div>
                <el-row class="pic1">
                  <el-col :span="24">
                    <a href="https://sports.qq.com/kbsweb/game.htm?mid=100000:55077384">
                       <img src="//img1.gtimg.com/ninja/2/2020/12/ninja160825745841478.jpg" alt="">
                    </a>
                  </el-col>
                </el-row>
                <el-row type="flex" justify="space-between">
                  <el-col :span="12" class="pic2">
                    <a href="">
                      <img src="//puui.qpic.cn/vpic/0/k0035eoarol.png/0" alt="">
                    </a>
                  </el-col>
                  <el-col :span="12" class="pic2">
                    <a href="">
                       <img src="//puui.qpic.cn/vpic/0/k0035eoarol.png/0" alt="">
                    </a>
                  </el-col>
                </el-row>
             </div>
          </el-col>
      </el-row>
    </div>
</template>

<script>
export default {
  name:'',
  data(){
   return { 
      img_list:[
         'https://ss0.bdstatic.com/70cFuHSh_Q1YnxGkpoWK1HF6hhy/it/u=3496380345,392612167&fm=26&gp=0.jpg',
         'https://ss0.bdstatic.com/70cFvHSh_Q1YnxGkpoWK1HF6hhy/it/u=3639430839,99369477&fm=26&gp=0.jpg',
         'https://ss0.bdstatic.com/70cFuHSh_Q1YnxGkpoWK1HF6hhy/it/u=3460587013,3036153139&fm=26&gp=0.jpg',
         'https://ss2.bdstatic.com/70cFvnSh_Q1YnxGkpoWK1HF6hhy/it/u=1507157276,472258692&fm=26&gp=0.jpg',
         'https://ss0.bdstatic.com/70cFuHSh_Q1YnxGkpoWK1HF6hhy/it/u=3909822170,2902176492&fm=26&gp=0.jpg'
      ]
   }
  }
}
</script>

<style scoped>
  .carousel-header{
    width: 1240px;
    height: 395px;
  }
  .carousel-header img{
    width: 100%;
  }
  .carousel{
    width: 100%;
  }
  .el-carousel__item:nth-child(2n) {
    background-color: #99a9bf;
  }
  .el-carousel__item:nth-child(2n+1) {
    background-color: #d3dce6;
  }

  .title{
    width: 1240px;
    height: 47px;
    display: flex;
  }
  .title h3{
    font-size: 22px;
    width: 170px;
    height: 47px;
    line-height: 47px;
    text-align: center;
    color: #fff;
    font-weight: 400;
    background-image: url(https://mat1.gtimg.com/pingjs/ext2020/nba/index/2018/images/block_title_bg-e3dd9adf39.png);
    background-repeat: no-repeat;
    background-position: 0 0;
  }
  .title div{
    border-bottom: 2px solid #d33556;
    margin-bottom: 2px;
    height: 45px;
    line-height: 45px;
    width: 1200px;
    margin-left: -35px;
  }

  .content{
    width: 520px;
    margin-top: 20px;
    margin-right: 20px;
    line-height: 34px;
  }
  .picture{
    margin-top: 20px;
    width: 680px;
    height: 528px;
    display: flex;
    justify-content: center;
  }
  .picture div{
    box-shadow: 0 2px 12px 0 rgba(27, 26, 26, 0.5);
  }
  .picture .pic1 img{
    width: 650px;
    height: 364px;
  }
  .pic2{
    height: 160px;
    width: 320px;
  }
  .pic2 a{
    width: 100%;
    height: 100%;
    position: relative;
    display: inline-block;
  }
  .pic2 a img{
    width: 100%;
    height: 100%;
    position: absolute;
  }
  /* .pic2{
    width: 320px;
    height: 180px;
  }
  .pic2 a{
    width: 100%;
    height: 100%;
  }
  .pic2 a img{
    width: 100%;
    height: 100%;
  } */
</style>
