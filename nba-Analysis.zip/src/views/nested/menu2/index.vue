<template>
   <div style="height: 1000px;background: #f6f6f6">
       <!--顶部按钮-->
       <btn-head>
           <btn-item v-for="(item,index) in btnsRow1" :key="index" :iconPath="item.iconPath" :des="item.des" slot="firstRow"  @click.native="refreshData(item)"></btn-item>
           <btn-item v-for="(item,index) in btnsRow2" :key="index" :iconPath="item.iconPath" :des="item.des" slot="secondRow" @click.native="refreshData(item)"></btn-item>
       </btn-head>

       <!--排名列表+图-->
       <el-row type="flex" justify="start" class="rank-all">
            <el-col :span="8" class="rank-list">
               <rank-list :name="curBtn" :list="list"></rank-list>
            </el-col>
            <el-col :span="8" class="rank-chart">
                <el-tabs  v-model="ActivePage" :tab-position="'right'" style="height: 460px;width: 700px" @tab-click="handlePlayerChartRefresh">
                    <el-tab-pane v-for="(page,index) in player_pages" :key="index" :name="page.name" ref="childChart">
                        <span slot="label"><h3>{{page.name}}</h3></span>
                        <graph-charts v-if="page.name==nowPage_player && page.sign==1" :option="player_option_list[index]" style="width:577.5px;height:400px;margin-top:20px;margin-left:14px" :time="time"></graph-charts>
                        <graph-echarts v-if="page.name==nowPage_player && page.sign==2" :option="player_option_list[index]" style="width:577.5px;height:400px;margin-top:20px;margin-left:14px" :time="time"></graph-echarts>
                    </el-tab-pane>
                </el-tabs>
            </el-col>
        </el-row>
   </div>
</template>

<script>
import BtnHead from '@/components/btnHead/btnHead.vue'
import BtnItem from '@/components/btnHead/btnIteam.vue'
import RankList from '@/components/rankList/rankList.vue'
import GraphCharts from '@/components/highChart/GraphCharts.vue'
import GraphEcharts from '@/components/echart/GraphCharts.vue'
import { getPlayerRank } from '@/api/player'
import uuidv1 from 'uuid/v1'

export default {
  name:'',
  data(){
   return {
         btnsRow1: [
            {iconPath: require('../../../assets/img/罚球.png'),des: '罚球'},
            {iconPath: require('../../../assets/img/三分球.png'),des: '三分球'},
            {iconPath: require('../../../assets/img/篮板.png'),des: '篮板'},
            {iconPath: require('../../../assets/img/助攻.png'),des: '助攻'},
            {iconPath: require('../../../assets/img/抢断.png'),des: '抢断'},
         ],
         btnsRow2: [
            {iconPath: require('../../../assets/img/封盖.png'),des: '封盖'},
            {iconPath: require('../../../assets/img/失误.png'),des: '失误'},
            {iconPath: require('../../../assets/img/犯规.png'),des: '犯规'},
            {iconPath: require('../../../assets/img/得分.png'),des: '得分'}
         ],
         player_pages: [
             {name: '柱状图', id:'chart1', sign: 1},
             {name: '折线图', id:'chart2', sign: 2},
             {name: '饼状图', id:'chart3', sign: 1},
             {name: '面积图', id:'chart4', sign: 1}
         ],
         rankName: 'pointsPG',
         nowPage_player: '柱状图',
         ActivePage: '柱状图',
         curBtn:'得分',
        //  专项对比命中率数据
         list: [],
         //专项对比数据图像数据
         player_option_list: [
           //图一柱状图
            {
                chart: {
                  type: 'column'
                },
                title: {
                  text: this.rankName
                },
                xAxis: {
                  categories: ['赛季1', '赛季2', '赛季3', '赛季4', '赛季5']
                },
                yAxis: {
                  min: 0,
                  title: {
                    text: '总投球个数'
                  }
                },
                tooltip: {
                  pointFormat: '<span style="color:{series.color}">{series.name}</span>: <b>{point.y}</b>' +
                  '({point.percentage:.0f}%)<br/>', 
                  //:.0f 表示保留 0 位小数，详见教程：https://www.hcharts.cn/docs/basic-labels-string-formatting
                  shared: true
                },
                plotOptions: {
                  column: {
                    stacking: 'percent'
                  }
                },
                //球员数据每个赛季柱状图
                series: [{
                  name: '詹姆斯-哈登',
                  data: [5, 3, 4, 7, 2]
                }, {
                  name: '布拉德利-比尔',
                  data: [2, 2, 3, 2, 1]
                }, {
                  name: '达米安-利拉德',
                  data: [3, 4, 4, 2, 5]
                }, {
                  name: '特雷-杨',
                  data: [2, 2, 4, 1, 1]
                }, {
                  name: '扬尼斯-阿德托昆博',
                  data: [4, 2, 5, 2, 1]
                }]
            },
            //折线图
            {
              title: {
                  text: this.rankName
              },
              tooltip: {
                  trigger: 'axis'
              },
              legend: {
                  data: ['詹姆斯-哈登', '布拉德利-比尔', '达米安-利拉德', '特雷-杨', '扬尼斯-阿德托昆博']
              },
              grid: {
                  left: '3%',
                  right: '4%',
                  bottom: '3%',
                  containLabel: true
              },
              xAxis: {
                  type: 'category',
                  boundaryGap: false,
                  data: ['赛季1', '赛季2', '赛季3', '赛季4', '赛季5']
              },
              yAxis: {
                  type: 'value'
              },
              //折线图数据五赛季
              series: [
                  {
                      name: '詹姆斯-哈登',
                      type: 'line',
                      data: [120, 132, 101, 134, 90]
                  },
                  {
                      name: '布拉德利-比尔',
                      type: 'line',
                      data: [220, 182, 191, 234, 29]
                  },
                  {
                      name: '达米安-利拉德',
                      type: 'line',
                      data: [150, 232, 201, 154, 190]
                  },
                  {
                      name: '特雷-杨',
                      type: 'line',
                      data: [320, 332, 301, 334, 390]
                  },
                  {
                      name: '扬尼斯-阿德托昆博',
                      type: 'line',
                      data: [111, 222, 444, 212, 123]
                  }
              ]
            },
            //饼状图
            {
            title: {
              text: this.rankName,
              align: 'center',
              verticalAlign: 'middle',
              y: 50
            },
            tooltip: {
              headerFormat: '{series.name}<br>',
              pointFormat: '{point.name}: <b>{point.percentage:.1f}%</b>'
            },
            plotOptions: {
              pie: {
                dataLabels: {
                  enabled: true,
                  distance: -50,
                  style: {
                    fontWeight: 'bold',
                    color: 'white',
                    textShadow: '0px 1px 2px black'
                  }
                },
                startAngle: -90, // 圆环的开始角度
                endAngle: 90,    // 圆环的结束角度
                center: ['50%', '75%']
              }
            },
            //饼状图数据
            series: [{
              type: 'pie',
              name: '标题',
              innerSize: '50%',
              data: [
                ['球员1',   45.0],
                ['球员2',       26.8],
                ['球员3', 12.8],
                ['球员4',    8.5],
                ['球员5',     6.2],
                {
                  name: '其他',
                  y: 0.7,
                  dataLabels: {
                    // 数据比较少，没有空间显示数据标签，所以将其关闭
                    enabled: false
                  }
                }
              ]
            }]
            },
            //面积图
            {
                chart: {
                  type: 'area'
                },
                title: {
                  text: this.rankName
                },
                subtitle: {
                  text: '虎扑体育、腾讯体育'
                },
                xAxis: {
                  categories: ['赛季1','赛季2','赛季3','赛季4','赛季5'],
                  tickmarkPlacement: 'on',
                  title: {
                    enabled: false
                  }
                },
                yAxis: {
                  title: {
                    text: '个'
                  },
                  labels: {
                    formatter: function () {
                      return this.value / 1;
                    }
                  }
                },
                tooltip: {
                  split: true,
                  valueSuffix: ' 个'
                },
                plotOptions: {
                  area: {
                    stacking: 'normal',
                    lineColor: '#666666',
                    lineWidth: 1,
                    marker: {
                      lineWidth: 1,
                      lineColor: '#666666'
                    }
                  }
                },
                //面积图数据
                series: [{
                  name: '球员1',
                  data: [502, 635, 809, 947, 1402]
                }, {
                  name: '球员2',
                  data: [106, 107, 111, 133, 221]
                }, {
                  name: '球员3',
                  data: [163, 203, 276, 408, 547]
                }, {
                  name: '球员4',
                  data: [18, 31, 54, 156, 339]
                }, {
                  name: '球员5',
                  data: [2, 2, 2, 6, 13]
                }]
            }
                    ],
         time: ""
         }
  },
  components:{
    BtnHead,
    BtnItem,
    RankList,
    GraphCharts,
    GraphEcharts
  },
  methods:{
      refreshData(item){
          this.curBtn=item.des
          switch(item.des){
            case '排名':
              this.rankName='final_rank'
              break;
            case '罚球':
              this.rankName='ftMadePG'
              break;
            case '三分球':
              this.rankName='threesPCT'
              break;
            case '篮板':
              this.rankName='reboundsPG'
              break;
            case '助攻':
              this.rankName='assistsPG'
              break;
            case '抢断':
              this.rankName='stealsPG'
              break;
            case '封盖':
              this.rankName='blocksPG'
              break;
            case '失误':
              this.rankName='turnoversPG'
              break;
            case '犯规':
              this.rankName='foulsPG'
              break;
            case '得分':
              this.rankName='pointsPG'
              break;
            default: {}
          }
      },
      handlePlayerChartRefresh(tab){  //点击图形类型切换
          console.log(tab)
          this.nowPage_player = tab.name
          this.repaintPage()
      },
      repaintPage(){              //重新渲染图形数据
          switch(this.nowPage_player){
            case '柱状图':
              {
                  let temp = []
                  for(var i=0;i<5;i++){
                     temp.push(
                       {
                        name: this.list[i].name,
                        data: [this.list[i].first_season,this.list[i].second_season,this.list[i].third_season,this.list[i].forth_season,this.list[i].fifth_season]
                      })
                  }
                   this.player_option_list[0].series=temp
              }break;
            case '折线图':
              {
                  let legend = []
                  let series = []
                  for(var i=0;i<5;i++){
                     legend.push(this.list[i].name)
                     series.push(
                        {  
                            name: this.list[i].name,
                            type: 'line',
                            data: [this.list[i].first_season,this.list[i].second_season,this.list[i].third_season,this.list[i].forth_season,this.list[i].fifth_season]
                        }
                     )
                  }
                  this.player_option_list[1].legend.data=legend
                  this.player_option_list[1].series=series
              }break;
            case '饼状图':
              {
                    var temp = []
                    for(var i=0;i<5;i++){
                      temp.push([this.list[i].name,this.list[i].first_season])
                    }
                    this.player_option_list[2].series[0].data=temp
              }break;
            case '面积图':
              {
                  let temp = []
                  for(var i=0;i<5;i++){
                     temp.push(
                       {
                        name: this.list[i].name,
                        data: [this.list[i].first_season,this.list[i].second_season,this.list[i].third_season,this.list[i].forth_season,this.list[i].fifth_season]
                      })
                  }
                   this.player_option_list[3].series=temp
              }
          }
          //更新time值子组件重画
          this.time=uuidv1()
      },
      renderAllData(){            //整体数据渲染
          getPlayerRank({
              "item": this.rankName
          }).then(res=>{
              this.list = res.data
              this.repaintPage()    //初始时需要将对图像进行数据渲染
          })
      }
  },
  mounted(){
     this.renderAllData()
  },
  watch:{    //监控rankName，当点击不同的button时对页面数据进行重新渲染
    rankName(newName,oldName){
        this.renderAllData()
    }
  }
}
</script>

<style scoped>
.rank-all{
    width: 90%;
    max-height: 600px;
    margin: 40px auto 20px auto;
}
.rank-chart{
    display: flex;
    align-items: center;
    margin-left: 50px;
    width: 700px;
}
.rank-list{
    margin-left: 40px;
}
.rank-chart div{
    box-shadow: 0 2px 12px 0 rgba(0,0,0,.1);
}
.rank-chart >>> .el-tabs__item{
    height: 80px;
    line-height: 5;
}
</style>
