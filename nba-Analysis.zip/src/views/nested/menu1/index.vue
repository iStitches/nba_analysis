<template>
   <div style="height: 1400px;background: #f6f6f6">
     <div class="rank_head">
       <div>
          <img src="https://ss0.bdstatic.com/70cFuHSh_Q1YnxGkpoWK1HF6hhy/it/u=1009333215,4232687855&fm=26&gp=0.jpg" alt="">
          <h3>球员数据</h3>
       </div>
     </div>
     <el-row type="flex" class="rank_body">
        <el-col :span="8" class="rank_item">
           <div class="test">
              <rank-list :list="averageScore" :name="'均厂得分'"></rank-list>
           </div>
        </el-col>
        <el-col :span="8" class="rank_item" style="margin: 21px">
           <div class="test">
              <rank-list :list="averageBoard" :name="'均厂篮板'"></rank-list>
           </div>
        </el-col>
        <el-col :span="8" class="rank_item">
           <div class="test">
              <rank-list :list="averageHelp" :name="'均厂助攻'"></rank-list>
           </div>
        </el-col>
     </el-row>
          <el-row type="flex" class="rank_body">
        <el-col :span="8" class="rank_item">
           <div class="test">
              <rank-list :list="averageRob" :name="'均厂抢断'"></rank-list>
           </div>
        </el-col>
        <el-col :span="8" class="rank_item" style="margin: 21px">
           <div class="test">
              <rank-list :list="averageGap" :name="'均厂盖帽'"></rank-list>
           </div>
        </el-col>
        <el-col :span="8" class="rank_item">
           <div class="test">
              <rank-list :list="averageFault" :name="'均厂失误'"></rank-list>
           </div>
        </el-col>
     </el-row>
   </div>
</template>

<script>
import RankList from '@/components/rankList/rankList.vue'
import { getPlayerRank } from '@/api/player'

export default {
  name:'',
  data(){
   return {
      averageScore:[],
      averageBoard:[],
      averageHelp:[],
      averageRob:[],
      averageGap:[],
      averageFault:[]
   }
  },
  components: {
    RankList,
  },
  mounted(){
     Promise.all([
        new Promise((resolve,reject)=>{
           getPlayerRank({
              "item":"pointsPG"
           }).then(res=>{
              resolve(res)
           })
        }),
        new Promise((resolve,reject)=>{
           getPlayerRank({
              "item":"reboundsPG"
           }).then(res=>{
              resolve(res)
           })
        }),
        new Promise((resolve,reject)=>{
           getPlayerRank({
              "item":"assistsPG"
           }).then(res=>{
              resolve(res)
           })
        }),
        new Promise((resolve,reject)=>{
           getPlayerRank({
              "item":"stealsPG"
           }).then(res=>{
              resolve(res)
           })
        }),
        new Promise((resolve,reject)=>{
           getPlayerRank({
              "item":"blocksPG"
           }).then(res=>{
              resolve(res)
           })
        }),
        new Promise((resolve,reject)=>{
           getPlayerRank({
              "item":"turnoversPG"
           }).then(res=>{
              resolve(res)
           })
        })
     ]).then(res=>{
         for(var i=0;i<5;i++){
               this.averageScore.push({
                     name: res[0].data[i].name,
                     img: res[0].data[i].img,
                     score: res[0].data[i].score
               })
               this.averageBoard.push({
                     name: res[1].data[i].name,
                     img: res[1].data[i].img,
                     score: res[1].data[i].score
               })
               this.averageHelp.push({
                     name: res[2].data[i].name,
                     img: res[2].data[i].img,
                     score: res[2].data[i].score
               })
               this.averageRob.push({
                     name: res[3].data[i].name,
                     img: res[3].data[i].img,
                     score: res[3].data[i].score
               })
               this.averageGap.push({
                     name: res[4].data[i].name,
                     img: res[4].data[i].img,
                     score: res[4].data[i].score
               })
               this.averageFault.push({
                     name: res[5].data[i].name,
                     img: res[5].data[i].img,
                     score: res[5].data[i].score
               })
            }
     })

   //   getPlayerRank({
   //      "item": "pointsPG"
   //   }).then(res=>{
   //      console.log(res)
   //      for(var i=0;i<5;i++){
   //          this.averageScore.push({
   //                name: res.data[i].name,
   //                img: res.data[i].img,
   //                score: res.data[i].score
   //          })
   //      }
   //   })
  }
}
</script>

<style scoped>
.test{
  width: 400px;
  border: 1px solid black;
}
.rank_head{
  width: 1242px;
  height: 62px;
  margin-top: 30px;
  display: flex;
  justify-content: flex-start;
  align-items: center;
  border: 1px solid #e2e2e2;
  background: #F23D63;
  margin-left: auto;
  margin-right: auto;
  box-shadow:  0 2px 12px 0 rgba(242,61,99,.5);
}
.rank_head div{
  display: flex;
  align-items: center;
  background: #f6f6f6;
  margin-left: 50px;
  box-shadow:  0 2px 12px 0 rgba(0,0,0,.5);
}
.rank_head img{
  width: 40px;
  height: 40px;
}
.rank_head h3{
  margin-left: 40px;
  margin-right: 40px;
}

.rank_body{
  width: 1242px;
  margin-left: auto;
  margin-right: auto;
}

.rank_body .rank_item{
  width: 400px;
  margin: 21px 0;
}
</style>
