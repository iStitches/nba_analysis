<template>
    <div class="main" style="height: 1000px;background: #f6f6f6">
      <!--MVP介绍-->
      <el-row type="flex" justify="center" style="margin-top:20px">
        <div style="padding:5px;background: #dfeeed2e" class="header-info">
          <el-col :span="6" class="header-item">
              <div class="info-card">
                 <img :src="personInfo.playersrc" alt="">
                 <div>{{personInfo.chname}}</div>
                 <span class="name">{{personInfo.enname}}</span>
                 <span class="score">25.3分 | 7.8篮板 | 10.2助攻</span>
                 <div class="corner">
                   <img :src="personInfo.teamsrc" alt="">
                   <div>{{personInfo.team}}</div>
                 </div>
              </div>
          </el-col>
          <el-col :span="6" class="header-item">
              <div class="info-card">
                 <div class="info-title">球员信息</div>
                 <p class="info-person">
                    号码：# {{personInfo.number}} <br>
                    位置： {{personInfo.location}} <br>
                    身高： {{personInfo.height}}CM <br>
                    体重： {{personInfo.weight}}KG <br>
                    生日： {{personInfo.birthday}} <br>
                    球队： {{personInfo.team}}<br>
                    选秀年：{{personInfo.starYear}}<br>
                 </p>
              </div>
          </el-col>
          <el-col :span="6" class="header-item">
              <div class="info-card">
                <div class="info-title">球员实力</div>
                <graph-echarts :option="personStrength" :width="width" :height="height" :time="time"></graph-echarts>
              </div>
          </el-col>
          <el-col :span="6" class="header-item">
              <div class="info-card">
                   <div class="info-title">球员荣誉</div>
                   <h4 v-for="(item,index) in personInfo.honor" :key="index" class="info-prize">{{index+1+'.'}}{{item}}</h4>
              </div>
          </el-col>
        </div>
      </el-row>

      <!--赛季数据-->
      <el-row type="flex" class="season-data">
        <el-col :span="24">
            <div class="title">
               赛季数据
            </div>
            <el-tabs  v-model="activeName" :tab-position="'top'" style="height: 500px;width: 1190px;margin-left: 30px" @tab-click="refreshData">
                <el-tab-pane v-for="(page,index) in pages" :key="index" :name="page.name" :label="page.name" class="data-tab">
                    <h3>常规赛平均得分：{{average}}</h3>
                    <graph-echarts v-if="page.name==nowPage" :option="detailStrength" :width="'1190px'" :height="'400px'" :time="time1"></graph-echarts>
                </el-tab-pane>
            </el-tabs>
        </el-col>
      </el-row>
    </div>
</template>

<script>
import GraphEcharts from '@/components/echart/GraphCharts.vue'
const echarts = require('echarts');
//引入提示框和图例组件
import uuidv1 from 'uuid/v1'
import { getPersonInfo } from '@/api/mvp'
import { getDetail } from '@/api/mvp'
import { getStrength } from '@/api/mvp'

export default {
  name:'',
  data(){
   return {
      personInfo:{       //球员个人数据
          chname: "勒布朗-詹姆斯",
          enname: "LeBron James",
          playersrc: "https://nba.sports.qq.com/media/img/players/head/260x190/2544.png",   //mvp头像
          teamsrc: "http://mat1.gtimg.com/sports/nba/logo/1602/13.png",     //mvp 所属球队的头像
          number: "23",
          location: "前锋",
          height: "205",
          weight: "113.4",
          birthday: "1984-12-30",
          team: "湖人",
          starYear: "2003",        //选秀年 
          honor:[                  //获得的荣誉
              "四届NBA最有价值球员奖（2009，2010，2012，2013）",
              "四届NBA总决赛最有价值球员奖（2012，2013，2016，2020）",
              "三届NBA全明星赛最有价值球员奖（2006，2008，2018）",
              "四届NBA总冠军（2012，2013，2016，2020）",
              "两届奥运会冠军（2008，2012）",
              "2019-20赛季NBA助攻王"
          ]
      },
      personStrength:{           //mvp 个人实力
            tooltip: {
                trigger: 'axis'
            },
            radar: [
                {
                    indicator: [
                        {text: '均厂得分', max: 100},
                        {text: '均厂助攻', max: 100},
                        {text: '均厂篮板', max: 100},
                        {text: '均厂抢断', max: 100},
                        {text: '均厂盖帽', max: 100}
                    ],
                    radius: 80,
                    nameGap : 3
                }
            ],
            series: [
                {
                    type: 'radar',
                    tooltip: {
                        trigger: 'item'
                    },
                    areaStyle: {},
                    data: [
                        {
                            value: [87,70,75,80,76],
                            name: '詹姆斯',
                            areaStyle: {
                                color: 'rgba(141,202,243,0.5)'
                            }
                        }
                    ]
                }
            ]
      },
      width: '260px',
      height: '240px',
      activeName: '场均得分',    //默认显示数据项
      nowPage: '场均得分',       //当前显示的数据项
      curItem: 'pointsPG',
      pages: [
          {name: '场均得分',sign: 2, id:'score'},
          {name: '命中率', sign: 2, id:'shotRate'},
          {name: '总得分', sign: 2, id:'threeScore'},
          {name: '三分命中率', sign: 2, id:'threeRate'},
          {name: '助攻',sign: 2, id:'help'},
          {name: '抢断',sign: 2, id:'rob'},
          {name: '盖帽',sign: 2, id:'cover'},
          {name: '失误',sign: 2, id:'fault'},
          {name: '犯规',sign: 2, id:'error'}
        ],
      average: '34.3',       //常规赛平均得分

      detailStrength:          //mvp单项数据
        {
          backgroundColor: '#051F38',
          xAxis: {
              type: 'category',
              data: ['赛季1', '赛季2', '赛季3', '赛季4', '赛季5']
          },
          yAxis: {
              type: 'value'
          },
            tooltip: {
            trigger: 'axis',
            axisPointer: {
                type: 'cross',
                label: {
                    backgroundColor: '#6a7985'
                }
            },
            nameTextStyle: {
                color: "#fff",
                rich: {
                    color: "#fff"
                }
            },
            axisLine: { // 坐标轴小标记
                lineStyle: { // 属性lineStyle控制线条样式
                    // fontWeight : 'bolder',
                    color: '#1d364a',
                    // shadowColor : '#1d364a', // 默认透明
                    width: 1
                }
            },
          },
          series: [{
              data: [820, 932, 901, 934, 1290],
              type: 'line',
              areaStyle: { //渐变色
              normal: {
                  color: new echarts.graphic.LinearGradient(
                      0, 0, 0, 1,
                      [
                          {offset: 0, color: 'rgba(2,237,255,0.6)'},
                          {offset: 0.5, color: 'rgba(2,237,255,0.3)'},
                          {offset: 1, color: 'rgba(2,237,255,0.1)'}
                      ]
                  )
              }},
              itemStyle: {
                  // color: '#02edff',
                  normal:{
                      label:{show:true},
                      color:"#02edff"
                  }
              },
              symbol: 'circle',     //设定为实心点
              symbolSize: 10,   //设定实心点的大小
              center: [20, 50],
          }]
        },
      time: '1',
      time1: '2'
   }
  },
  components:{
    GraphEcharts
  },
  methods: {
    refreshData(tab){           //图标切换
          this.nowPage = tab.name
          switch(tab.name){     //修改curItem 值进行axios数据传输
                case '场均得分':
                    this.curItem='pointsPG'
                    break;
                case '命中率':
                    this.curItem='fgPCT'
                    break;
                case '总得分':
                    this.curItem='points'
                    break;
                case '三分命中率':
                    this.curItem='threesPCT'
                    break;
                case '助攻':
                    this.curItem='assistsPG'
                    break;
                case '抢断':
                    this.curItem='stealsPG'
                    break;
                case '封盖':
                    this.curItem='blocksPG'
                    break;
                case '失误':
                    this.curItem='turnoversPG'
                    break;
                case '犯规':
                    this.curItem='foulsPG'
                    break;
                default: {}
                }
       this.getItemStrength()
    },
    getMvpPersonInfo(){      //获取个人介绍数据
    //    getPersonInfo().then(res=>{
    //        this.personInfo = res.data
    //    })
       return getPersonInfo()
    },
    getDetailStrength(){     //获取mvp实力数据
    //    this.personStrength.series[0].data[0].value = res.data
       return personStrength()
    },
    getItemStrength(){       //获取单项数据
       getDetail({
           "item":this.curItem
       }).then(res=>{
           console.log("ahhahahahah")
           this.detailStrength.series[0].data = res.data
           this.time1=uuidv1()
       })
    }
  },
  mounted(){
    this.getItemStrength()
    console.log("我是初始值")
    console.log(this.detailStrength)
  }
}
</script>

<style scoped>
@import '../../assets/css/mvp/mvp.css';

.season-data{
  width: 1255px;
  height: 560px;
  margin-top: 25px;
  margin-left: auto;
  margin-right: auto;
  box-shadow: 0 2px 12px 0 #58ced8cc;
}
.season-data .title{
  height: 48px;
  font-size: 20px;
  padding: 15px;
}
.data-tab h3{
  text-align: center;
  margin-top: 5px;
  color: #5d5d5d;
  margin-bottom: 12px;
}
.season-data >>> .el-tabs__item{
  font-size: 16px;
  font-weight: 600;
  color: #F23E65;
}
.season-data >>> .el-tabs__nav-scroll{
  display: flex;
  justify-content: center;
}
</style>
