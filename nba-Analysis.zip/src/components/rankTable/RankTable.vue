<template>
    <el-table
      :data="tableData"
      style="width: 85%"
      max-height="1200" class="team-rank">
      <el-table-column
        fixed
        label="排名"
        width="100" align="center">
        <template slot-scope="scope">
          <div class="rank-num">{{scope.row.Rank}}</div>
        </template>
      </el-table-column>
      <el-table-column
        label="球队"
        width="150" align="center">
        <template slot-scope="scope">
            <el-popover trigger="hover" placement="top">
                    <div class="team-tip">
                      <dl>
                        <dt>中文名</dt>
                        <dd>{{scope.row.TeamName}}</dd>
                        <dt>英文名</dt>
                        <dd>{{scope.row.chname}}</dd>
                        <dt>成立时间</dt>
                        <dd>{{scope.row.creattime}}</dd>
                        <dt>所属地区</dt>
                        <dd>{{scope.row.area}}</dd>
                        <dt>知名人物</dt>
                        <dd>{{scope.row.famous}}</dd>
                      </dl>
                    </div>
                    <div slot="reference" class="team-wrapper">
                      <img :src="scope.row.img" alt="" width="40px" height="50px">
                      <el-tag effect="dark" type="warning">{{scope.row.nickname}}</el-tag>
                    </div>
            </el-popover>
        </template>
      </el-table-column>
      <el-table-column
        label="助攻"
        width="120"
        prop="Assist" align="center">
      </el-table-column>
      <el-table-column
        label="失误"
        width="120"
        prop="Fault" align="center">
      </el-table-column>
      <el-table-column
        label="犯规"
        width="120"
        prop="Illegal" align="center">
      </el-table-column>
      <el-table-column
        label="抢断"
        width="120"
        prop="Intercept" align="center">
      </el-table-column>
      <el-table-column
        label="盖帽"
        width="120"
        prop="NutCap" align="center">
      </el-table-column>
      <el-table-column
        label="罚球率"
        width="120"
        prop="PenaltyAccuracy" align="center">
      </el-table-column>
      <el-table-column
        label="篮板"
        width="120"
        prop="Rebounds" align="center">
      </el-table-column>
      <el-table-column
        label="得分"
        width="120"
        prop="Scores" align="center">
      </el-table-column>
      <el-table-column
        label="投篮命中率"
        width="220"
        prop="ShotAccuracy" align="center">
      </el-table-column>
      <el-table-column
        label="三分命中率"
        width="220"
        prop="TrebleAccuracy" align="center">
      </el-table-column>
    </el-table>
</template>

<script>
export default {
  name:'',
  data(){
   return {

   }
  },
  props:{
      tableData:{
          type: Array
      }
  }
}
</script>

<style scoped>

.team-rank{
  margin-top: 20px;
  margin-left: auto;
  margin-right: auto;
  text-align: center;
}
.team-wrapper{
  display: flex;
  align-items: center;
  justify-content: space-evenly;
}
.rank-num{
  background: #2d85d5;
  border-radius: 2px;
  width: 36px;
  height: 36px;
  text-align: center;
  padding: 5px;
  color: white;
  margin-left: auto;
  margin-right: auto;
}
.team-tip dt{
  float: left;
  color: black;
  font-weight: bold;
  padding: 0 5px 0 8px;
}
</style>
