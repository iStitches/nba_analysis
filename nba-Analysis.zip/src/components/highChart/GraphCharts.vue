<template> 
    <div :id="elId" :option="option" :style="{'width':width,'height':height}" :time="time"></div>
</template>

<script>
import uuidv1 from 'uuid/v1' 
import Highcharts from 'highcharts'

export default {
  name:'',
  data(){
   return {
      elId:""
   }
  },
  methods:{
     drawLine(){
         Highcharts.chart(this.elId,this.option)
     }
  },
  props:{
      option: Object,
      width: {
          type: String,
          default: '700px'
      },
      height: {
          type: String,
          default: '450px'
      },
      time:""
  },
  created(){
      this.elId = uuidv1()
  },
  mounted(){
      this.drawLine()
  },
  watch:{
      time(){
          this.drawLine()
      }
  }
}
</script>

<style scoped>

</style>
