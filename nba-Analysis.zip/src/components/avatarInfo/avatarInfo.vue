<template>
    <div class="avatar-main">
        <el-row :gutter="10" type="flex" class="row-bg" justify="start">
            <el-col :span="8">
                <div class="grid-a-contentWidth">
                    <img :src="teamInfo_imgList[0].img" alt="">
                </div>
            </el-col>
            <el-col :span="8">
                <div class="grid-a-contentWidth">
                    <img :src="teamInfo_imgList[1].img" alt="">
                </div>
            </el-col>
            <el-col :span="8">
                <div class="grid-a-contentWidth">
                    <img :src="teamInfo_imgList[2].img" alt="">
                </div>
            </el-col>
        </el-row>
        <br>
        <el-row :gutter="10" type="flex" class="row-bg" justify="start">
            <el-col :span="16">
                <div class="grid-a-content-a-Width">
                    <el-popover
                        placement="left-start"
                        width="200"
                        trigger="hover">
                        <img :src="teamInfo_imgList[3].img" alt="" slot="reference">
                        <div>
                            <span class="title">中文名：   </span> <span class="content">{{teamInfo.name}}</span><br>
                            <span class="title">所属地区： </span> <span class="content">{{teamInfo.area}}</span><br>
                            <span class="title">知名人物： </span> <span class="content">{{teamInfo.famous}}</span><br>
                            <span class="title">现任主教练： </span> <span class="content">{{teamInfo.coach}}</span><br>
                            <span class="title">主要荣誉： </span> <span class="content">{{teamInfo.honor}}</span><br>
                        </div>
                    </el-popover>
                </div>
            </el-col>
            <el-col :span="8">
                <div class="grid-a-contentWidth">
                    <img :src="teamInfo_imgList[4].img" alt="">
                </div>
                <br>
                <div class="grid-a-contentWidth">
                    <img :src="teamInfo_imgList[5].img" alt="">
                </div>
            </el-col>
        </el-row>  
    </div>
</template>

<script>
export default {
  name:'',
  data(){
   return {
   }
  },
  props:{
      teamInfo:{
          type: Object,
          default(){
              return {}
          }
      },
      teamInfo_imgList:{
          type: Array,
          default(){
              return []
          }
      }
  },
  created(){
    //   console.log(this.teamInfo)
  }
}
</script>

<style scoped>
.avatar-main{
    padding: 7px;
    background: #FFFFFF;
    box-shadow: 0 2px 12px 0 rgba(0,0,0,.1);
}
.grid-a-contentWidth {    
    border-radius: 4px;
    width: 160px;
    height: 120px;
    box-shadow: 0 2px 12px 0 #513daddb;
    border-radius: 10px;
  }
.grid-a-contentWidth img{
    width: 160px;
    height: 120px;
    border-radius: 10px;
}
  .grid-a-content-a-Width {    
    border-radius: 4px;
    height: 258.4px;
    width: 330px;
    display: flex;
    align-items: center;
    justify-content: center;
  }
.grid-a-content-a-Width img{
    width: 258.4px;
}
.title{
    font-size: 16px;
    font-weight: 700;
    color: rgb(115, 214, 33);
}
.content{
    font-size: 10px;
}
</style>
