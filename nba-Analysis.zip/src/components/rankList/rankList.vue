<template>
    <el-card class="box-card" :body-style="{padding: '10px'}">
        <div slot="header" class="rank-header">
            <span>{{name}}</span>
            <el-button style="float: right; padding: 3px 0" type="text">查看全部</el-button>
        </div>
        <div v-for="(item, index) in list" :key="index" :class="index===0? 'rank-body-first':'rank-body-normal'">
            <div :class="index===0?'num-first':'num-normal'">{{index+1}}</div>
            <img :src="item.img" alt="" :class="index===0?'img-first':'img-normal'">
            <div :class="index===0?'name-first':'name-normal'">{{item.name}}</div>
            <div :class="index===0?'score-first':'score-normal'">{{item.score}}</div>
        </div>
    </el-card>
</template>

<script>
export default {
  name:'',
  data(){
   return {

   }
  },
  props:{
    name: {
        type: String,
        default: '均厂得分'
    },
    list: {
        type: Array,
        default(){
            return [
                {
                    name: "密尔沃基雄鹿",
                    img: "http://mat1.gtimg.com/sports/nba/logo/1602/15.png",
                    score: 118.7
                },
                {
                    name: "密尔沃基雄鹿",
                    img: "http://mat1.gtimg.com/sports/nba/logo/1602/15.png",
                    score: 118.7
                },
                {
                    name: "密尔沃基雄鹿",
                    img: "http://mat1.gtimg.com/sports/nba/logo/1602/15.png",
                    score: 118.7
                },
                {
                    name: "密尔沃基雄鹿",
                    img: "http://mat1.gtimg.com/sports/nba/logo/1602/15.png",
                    score: 118.7
                },
                {
                    name: "密尔沃基雄鹿",
                    img: "http://mat1.gtimg.com/sports/nba/logo/1602/15.png",
                    score: 118.7
                },
                {
                    name: "密尔沃基雄鹿",
                    img: "http://mat1.gtimg.com/sports/nba/logo/1602/15.png",
                    score: 118.7
                }             
              ]
        }
    }
  }
}
</script>

<style scoped>
.rank-header span{
    font-size: 18px;
    text-align: center;
    color: #606060;
}
.box-card{
    display: flex;
    flex-direction: column;
}

.rank-body-normal{
    height: 74px;
    border: 1px solid #e2e2e2;
    display: flex;
    align-items: center;
    text-align: center;
    position: relative;
    color: #606060;
}

.rank-body-first{
    height: 123px;
    border: 1px solid #e2e2e2;
    display: flex;
    align-items: center;
    text-align: center;
    position: relative;
    color: #606060;
}
.num-first{
    font-size: 30px;
    width: 45px;
    height: 45px;
    line-height: 45px;
    margin: 0 8px 0;
}
.num-normal{
    font-size: 14px;
    width: 25px;
    height: 22px;
    line-height: 22px;
    margin: 0 22px 0;
    background: white;
}
.name-first{
    font-size: 16px;
    font-weight: bold;
    margin: 0 12px 0;
    color: #000;
}
.name-normal{
    font-size: 14px;
    font-weight: bold;
    margin: 0 24px 0;
    color: #000;
}
.score-first{
    font-size: 22px;
    position: absolute;
    font-weight: 700;
    right: 10px;
}
.score-normal{
    font-size: 16px;
    position: absolute;
    right: 18px;
}
.img-first{
    max-width: 85px;
    max-height: 85px;
    margin: 0 8px 0;
}
.img-normal{
    max-width: 55px;
    max-height: 55px;
    margin: 0 16px 0;
}
</style>
