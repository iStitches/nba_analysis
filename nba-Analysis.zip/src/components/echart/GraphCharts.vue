<template>
      <div :id="elId" :style="{'width':width,'height':height}" :time="time"></div>
</template>

<script>
//引入基本模板
// import uuidv1 from 'uuid/v1' 
// //引入提示框和图例组件
// import 'echarts/lib/component/tooltip'
// import 'echarts/lib/component/legend'
const echarts = require('echarts');
import 'echarts/lib/component/tooltip'
import 'echarts/lib/component/legend'
import uuidv1 from 'uuid/v1'

export default {
  name:'',
  data(){
   return { 
       elId: ''
   }
  },
  props:{
      width:{
          type: String,
          default: '100%'
      },
      height:{
          type: String,
          default: '80vh'
      },
      option: Object,
      time: String
  },
  created(){
      this.elId = uuidv1()
      console.log("初始化eid",this.elId)
  },
  mounted() {
      console.log(document.getElementById(this.elId))
      this.drawLine()
  },
  methods: {
      drawLine(){
        console.log(this.option)
        console.log(document.getElementById(this.elId))
        var myChart = echarts.init(document.getElementById(this.elId))
        console.log(myChart)
        myChart.setOption(this.option)
      }
  },
  components:{
      echarts
  },
  watch:{
      time(){
          this.drawLine()
      }
  }
}
</script>

<style scoped>

</style>
