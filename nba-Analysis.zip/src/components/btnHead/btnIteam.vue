<template>
 <div>
    <el-col :span="4" class="btn-header" @mouseover.native="onMouseOver" :style="active" @mouseout.native="onMouseOut">
        <div class="btn">
        <img :src="iconPath" alt="">
        <span>{{des}}</span>
        </div>
    </el-col>
 </div>

</template>

<script>
export default {
  data(){
   return {
      active: ""
   }
  },
  props:{
      iconPath: String,
      des: String
  },
  methods:{
      onMouseOver(){
        let colorArray=['#3a8ee6','#c6e1e4','#66b1ff','#67c23a','#e6a23c','#44debf','#a07037','#9edae0','#968ace']
        this.active = 'background-color:'+colorArray[Math.floor(Math.random()*colorArray.length)]
      },
      onMouseOut(){
        this.active = ""
      }
  }
}
</script>

<style scoped>
.btn-header{
  border: 1px solid #2aede6;
  width: 180px;
  height: 130px;
  margin: 5px;
  box-shadow: 0 0 10px rgb(140, 212, 221);
  text-align: center;
}
.btn{
  display: flex;
  align-items: center;
  width: 100%;
  height: 100%;
  justify-content: space-evenly;
}
.btn-header img{
  width: 70px;
}
.btn-header span{
  font-size: 17px;
  font-weight: 600;
}
</style>
