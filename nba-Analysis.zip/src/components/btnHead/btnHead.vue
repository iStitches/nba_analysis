<template>
     <div id="team-top">
       <el-row type="flex" class="row-bg" justify="center">
          <slot name="firstRow"></slot>
       </el-row>
       <el-row type="flex" class="row-bg" justify="center">
          <slot name="secondRow"></slot>
       </el-row>
     </div>
</template>

<script>

export default {
  name:'',
  data(){
   return {
   }
  },
  methods: {

  },
  components:{
  }
}
</script>

<style scoped>
</style>
